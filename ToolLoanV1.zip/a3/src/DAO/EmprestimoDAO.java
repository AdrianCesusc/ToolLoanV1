package DAO;

import Model.Amigo;
import Model.Emprestimo;
import Model.Ferramenta;
import java.util.*;
import java.util.Date;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;


        public class EmprestimoDAO {
        public static ArrayList<Emprestimo> ListaEmprestimos = new ArrayList<Emprestimo>();    
        public EmprestimoDAO(){}


 public int maiorID() throws SQLException {

        int maiorID = 0;
        try {
            Statement stmt = this.getConexao().createStatement();
            ResultSet res = stmt.executeQuery("SELECT MAX(id) id FROM emprestimos");
            res.next();
            maiorID = res.getInt("id");

            stmt.close();

        } catch (SQLException ex) {
            
        }

        return maiorID;
    }

   public Connection getConexao() {

        Connection connection = null ;  //inst�ncia da conex�o

        try {

            // Carregamento do JDBC Driver
            String driver = "com.mysql.cj.jdbc.Driver";
            Class.forName(driver);

            // Configurar a conex�o
            String server = "localhost"; //caminho do MySQL
            String database = "db_gerenciadorv1";
            String url = "jdbc:mysql://" + server + ":3306/" + database + "?useTimezone=true&serverTimezone=UTC";
            String user = "root";
            String password = "Mudar@123.";

            connection = DriverManager.getConnection(url, user, password);

            // Testando..
            if (connection != null) {
                System.out.println("Status: Conectado!");
            } else {
                System.out.println("Status: N�O CONECTADO!");
            }

            return connection;

        } catch (ClassNotFoundException e) {  //Driver n�o encontrado
            System.out.println("O driver nao foi encontrado. " + e.getMessage() );
            return null;

        } catch (SQLException e) {
            System.out.println("Nao foi possivel conectar...");
            return null;
        }
    }
   
       public ArrayList getListaEmprestimos() {
        
        ListaEmprestimos.clear(); // Limpa nosso ArrayList

        try {
            Statement stmt = this.getConexao().createStatement();
            ResultSet res = stmt.executeQuery("select e.id,f.nome as 'Ferramenta',a.nome as 'Amigo' ,e.data_devolucao,e.data_emprestimo, case when e.status = 1 then 'Devolvido' else 'Pendente' end as 'Status'from emprestimos e join ferramentas f on f.id = e.ferramenta_id join amigos a on a.id = e.amigo_id order by e.status");

            while (res.next()) {
                
               

                int id = res.getInt("id");
                String NomeFerramenta = res.getString("Ferramenta");            
                String NomeAmigo = res.getString("Amigo");
                String dataEmprestimo = res.getString("data_emprestimo");
                String dataDevolucao = res.getString("data_devolucao");
                String status = res.getString("status");
                
                Emprestimo objeto = new Emprestimo( id, NomeFerramenta,  NomeAmigo,  dataEmprestimo, dataDevolucao, status);

                ListaEmprestimos.add(objeto);
            }

            stmt.close();

        } catch (SQLException ex) {
        }

        return ListaEmprestimos;
    }
 public boolean CadastrarEmprestimoBD(Emprestimo objeto) {
        String sql = "INSERT INTO emprestimos( id, amigo_id, ferramenta_id, data_emprestimo, data_devolucao) VALUES(?,?,?,?,?)";

        
        
        try {
            PreparedStatement stmt = this.getConexao().prepareStatement(sql);
        
           
            
            stmt.setInt(1, objeto.getId());
            stmt.setInt(2, objeto.getAmigo());
            stmt.setInt(3, objeto.getFerramenta());             
            stmt.setString(4,objeto.getDataEmprestimo());         
            stmt.setString(5, objeto.getDataDevolucao());
           
            stmt.execute();
            stmt.close();

            return true;

        } catch (SQLException erro) {
            throw new RuntimeException(erro);
        }

 }
 
 public boolean devolvido(int id){
   try {
            Statement stmt = this.getConexao().createStatement();
            stmt.executeUpdate("UPDATE emprestimos SET STATUS = 1 WHERE id = " + id);
            stmt.close();            
            
        } catch (SQLException erro) {
        }
        
        return true;
    }

 

   public int TotalPendentes() throws SQLException {
        Statement stmt = this.getConexao().createStatement();
        ResultSet res = stmt.executeQuery("select count(id) as total from emprestimos where status is null");
        int total = 0;
        if (res.next()) {
            total = res.getInt("total");
        }
        stmt.close();
        return total;
    }
        
 
        
        
        
        }