
package Model;
import DAO.FerramentaDAO;
import java.sql.SQLException;
import java.util.ArrayList;

public class Ferramenta {
    private String nome;
    private String marca;
    private double custo;
    private int id;
    private final FerramentaDAO dao; 
        
        
       public Ferramenta() {
        this.dao = new FerramentaDAO(); 
    }    

    public Ferramenta(String nome, String marca,double custo,int id) {
        this.nome = nome;
        this.marca = marca;
        this.custo = custo;
        this.id =id;
        this.dao = new FerramentaDAO();
    }

    public String getNome() {
        return nome;
    }

    public String getMarca() {
        return marca;
    }

    public double getCusto() {
        return custo;
   }
    
      public int getId() {
        return id;
      }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
       public void setId(int id) {
        this.id = id;
    }
     public void setMarca(String marca) {
        this.marca = marca;
    }
    public void setCusto(double custo) {
        this.custo = custo;
    }
    
      public String ImprimeFerramenta() {
        return "\n Nome: " + this.getNome()
                + "\n Marca:" + this.getMarca()
                + "\n Custo:" + this.getCusto()
                + "\n -----------";      
     }
  
      
            public ArrayList getListaFerramentas() {
        return dao.getListaFerramentas();
    }
            
        public boolean CadastrarFerramentaBD(String nome, String marca, double custo) throws SQLException {
        int id = this.maiorID() + 1;
        Ferramenta objeto = new Ferramenta(nome,marca, custo,id);
        dao.CadastrarFerramentaBD(objeto);
        return true;

    }
        
        public boolean ExcluirFerramentaBD(int id) {
        dao.ExcluirFerramentaBD(id);
        return true;
    }  
           public boolean AtualizarFerramentaBD(String nome, String marca, int id, double custo) {
        Ferramenta objeto = new Ferramenta(nome,marca, custo,id);     
        dao.AtualizarFerramentaBD(objeto);
        return true;
    }
      
       public int maiorID() throws SQLException{
        return dao.maiorID();
    }         
}

