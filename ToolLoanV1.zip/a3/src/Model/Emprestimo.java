/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import DAO.EmprestimoDAO;
import DAO.FerramentaDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author adrian.miquilena
 */
public class Emprestimo {
    private int id;
    private int ferramentaid;
    private int amigoid;
    private String NomeAmigo;
    private String NomeFerramenta;
    private String dataEmprestimo;
    private String dataDevolucao;
    private String status;

 
    private final EmprestimoDAO dao; 

    
    
    public Emprestimo(){
                this.dao = new EmprestimoDAO(); // inicializado n�o importa em qual construtor

    }
    
    public Emprestimo(int id, String NomeFerramenta, String NomeAmigo,String dataEmprestimo,String dataDevolucao, String status){
         this.id = id;
        this.NomeFerramenta = NomeFerramenta;
        this.NomeAmigo = NomeAmigo;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataDevolucao;
        this.status = status;
        this.dao = new EmprestimoDAO();
    }

 
    

    public Emprestimo(int id,int amigoid,int ferramentaid, String dataEmprestimo,String dataDevolucao, String status) {
        this.id = id;
        this.ferramentaid = ferramentaid;
        this.amigoid = amigoid;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataDevolucao;
        this.status = status;
        this.dao = new EmprestimoDAO();

    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public int getFerramenta() {
        return ferramentaid;
    }

    public int getAmigo() {
        return amigoid;
    }

    public String getDataEmprestimo() {
        return dataEmprestimo;
    }

    public String getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(String dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }
    
    public void setFerramenta(int ferramenta) {
        this.ferramentaid = ferramentaid;
    }
    
      public void setAmigo(int amigo) {
        this.amigoid = amigoid;
    }
        public void setDataEmprestimo(String dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }
        
         public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
        public String getNomeAmigo() {
        return NomeAmigo;
    }

    public void setNomeAmigo(String NomeAmigo) {
        this.NomeAmigo = NomeAmigo;
    }

    public String getNomeFerramenta() {
        return NomeFerramenta;
    }

    public void setNomeFerramenta(String NomeFerramenta) {
        this.NomeFerramenta = NomeFerramenta;
    }   
        
        public boolean CadastrarEmprestimoBD( int ferramentaid, int amigoid, String dataEmprestimo,String dataDevolucao, String status) throws SQLException {
        int id = this.maiorID() + 1;
       
        Emprestimo objeto = new Emprestimo(id,ferramentaid,amigoid, dataEmprestimo,dataDevolucao,status);
        dao.CadastrarEmprestimoBD(objeto);
        return true;

    }
         public int maiorID() throws SQLException{

        return dao.maiorID();
    }  
      public String ImprimeEmprestimo() {
        return "\n ID: " + this.getId()
                + "\n ID da ferramenta: " + this.getFerramenta()
                + "\n ID do amigo:" + this.getAmigo()
                + "\n Data do emprestimo:" + this.getDataEmprestimo()
                  + "\n Data da devolução:" + this.getDataDevolucao()
                + "\n Status:" + this.getStatus()
                + "\n -----------";      
     }   

          public ArrayList getListaEmprestimos() {
        //return AlunoDAO.MinhaLista;
        return dao.getListaEmprestimos();
    }
    
     public boolean devolvido(int id)    {    
        return dao.devolvido(id);
     }
     
      public int TotalEmprestimo() throws SQLException{    
        return dao.TotalPendentes();
     }
        
}
