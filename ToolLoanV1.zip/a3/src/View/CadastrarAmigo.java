
package View;
import Model.Amigo;
import java.awt.Toolkit;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class CadastrarAmigo extends javax.swing.JFrame {
    
    private Amigo objAmigo;

  
    public CadastrarAmigo() {
        initComponents();
        this.objAmigo = new Amigo();
        setIcon();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        tefsd = new javax.swing.JLabel();
        tefsd1 = new javax.swing.JLabel();
        CadastrarFerramenta = new javax.swing.JToggleButton();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        TelefoneAmigo = new javax.swing.JFormattedTextField();
        NomeAmigo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        jLabel1.setFont(new java.awt.Font("Montserrat", 3, 18)); // NOI18N
        jLabel1.setText("Cadastro de Amigos");

        setTitle("Cadastro de Amigos");
        setPreferredSize(new java.awt.Dimension(310, 335));
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 362, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 0, 362);

        tefsd.setFont(new java.awt.Font("Montserrat", 3, 14)); // NOI18N
        tefsd.setForeground(new java.awt.Color(255, 255, 255));
        tefsd.setText("Nome:");
        getContentPane().add(tefsd);
        tefsd.setBounds(50, 80, 48, 18);

        tefsd1.setFont(new java.awt.Font("Montserrat", 3, 14)); // NOI18N
        tefsd1.setForeground(new java.awt.Color(255, 255, 255));
        tefsd1.setText("Telefone:");
        getContentPane().add(tefsd1);
        tefsd1.setBounds(30, 150, 68, 20);

        CadastrarFerramenta.setFont(new java.awt.Font("Montserrat", 2, 12)); // NOI18N
        CadastrarFerramenta.setText("CADASTRAR");
        CadastrarFerramenta.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        CadastrarFerramenta.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        CadastrarFerramenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CadastrarFerramentaActionPerformed(evt);
            }
        });
        getContentPane().add(CadastrarFerramenta);
        CadastrarFerramenta.setBounds(170, 250, 110, 32);

        jButton1.setFont(new java.awt.Font("Montserrat", 2, 10)); // NOI18N
        jButton1.setText("Cancelar");
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(30, 260, 60, 20);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TelefoneAmigo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        try {
            TelefoneAmigo.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)-#####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel2.add(TelefoneAmigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 140, 180, 30));

        NomeAmigo.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jPanel2.add(NomeAmigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, 179, 28));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/degradefundo1.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");
        jLabel2.setToolTipText("");
        jLabel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.blue, java.awt.Color.blue, java.awt.Color.blue));
        jLabel2.setMinimumSize(new java.awt.Dimension(400, 250));
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 310, 320));

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 0, 310, 320);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void CadastrarFerramentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CadastrarFerramentaActionPerformed
        try {
            // recebendo e validando os dados dos campos na interface gráfica
            String nome = "";
            String telefone = "";
            
            // é validado o tamanho dos valores inseridos nos campos 
            if (this.NomeAmigo.getText().length() < 2) {
                throw new Mensagens1("Por favor insira um nome maior de 2 digitos");
            } else {
                nome = this.NomeAmigo.getText();
            }
            if (this.TelefoneAmigo.getText().length() <= 0) {
                throw new Mensagens1("Telefone inválido");
            } else {
                telefone = this.TelefoneAmigo.getText();
            }
            
            
            // envia os dados para o DAO realizar o cadastro
            if (this.objAmigo.CadastrarAmigoBD(nome, telefone)) {
                JOptionPane.showMessageDialog(rootPane, "Amigo cadastrado com Sucesso!");

            // limpa os dados dos campos da interface
                this.NomeAmigo.setText("");
                this.TelefoneAmigo.setText("");
            }
            
            // imprimimos os dados do amigo cadastrado no output
                System.out.println(this.objAmigo.getListaAmigos().toString());
                
            // Capturamos os possiveis erros 
            } catch (Mensagens1 erro) {
                JOptionPane.showMessageDialog(null, erro.getMessage());
            } catch (NumberFormatException erro2) {
                JOptionPane.showMessageDialog(null, "Verifique os valores inseridos");
            } catch (SQLException ex) {
                Logger.getLogger(CadastrarFerramenta.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_CadastrarFerramentaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       this.setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CadastrarAmigo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CadastrarAmigo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CadastrarAmigo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CadastrarAmigo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastrarAmigo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton CadastrarFerramenta;
    private javax.swing.JTextField NomeAmigo;
    private javax.swing.JFormattedTextField TelefoneAmigo;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel tefsd;
    private javax.swing.JLabel tefsd1;
    // End of variables declaration//GEN-END:variables
    private void setIcon() {
setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon2.png")));
    }

}
