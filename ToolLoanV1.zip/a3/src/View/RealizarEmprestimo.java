
package View;

import DAO.AmigoDAO;
import Model.Ferramenta;
import DAO.FerramentaDAO;
import Model.Emprestimo;
import DAO.EmprestimoDAO;
import Model.Amigo;
import java.awt.Toolkit;
import java.util.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class RealizarEmprestimo extends javax.swing.JFrame {
 
    
    private Emprestimo objaluno ;
    
    
 //   java.util.Date Novoformato = new java.util.Date();
   // java.sql.Date sqlDate = new java.sql.Date(Novoformato.getTime());
   
  
    
    public RealizarEmprestimo() {
        initComponents();
        this.objaluno = new Emprestimo(); 
        PreencherCbxFerramentas();
        PreencherCbxAmigos();
        setIcon();
        
    } 
    
private void PreencherCbxFerramentas(){

    FerramentaDAO objferramenta = new FerramentaDAO();
    ArrayList <Ferramenta> listaCbxFerramentas = objferramenta.getListaFerramentas();
    cbxFerramenta.removeAllItems();
    
    for (int i = 0; i< listaCbxFerramentas.size();i++)
    {
    cbxFerramenta.addItem(listaCbxFerramentas.get(i).getNome());
    
    }
}

private void PreencherCbxAmigos(){

    AmigoDAO objamigo = new AmigoDAO();
    ArrayList <Amigo> listaCbxAmigos = objamigo.getListaAmigos();
    cbxAmigos.removeAllItems();
    
    for (int i = 0; i< listaCbxAmigos.size();i++)
    {
    cbxAmigos.addItem(listaCbxAmigos.get(i).getNome ());
    
    }
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jButton1 = new javax.swing.JButton();
        cbxAmigos = new javax.swing.JComboBox<>();
        cbxFerramenta = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        datadevolucao = new javax.swing.JFormattedTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();

        setTitle("Realizar um emprestimo");
        setBackground(new java.awt.Color(182, 239, 206));
        setMinimumSize(new java.awt.Dimension(300, 280));
        setPreferredSize(new java.awt.Dimension(477, 350));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Montserrat", 2, 12)); // NOI18N
        jButton1.setText("SALVAR");
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.black));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 240, 90, 40));

        cbxAmigos.setFont(new java.awt.Font("Montserrat", 2, 12)); // NOI18N
        cbxAmigos.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        getContentPane().add(cbxAmigos, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 440, 30));

        cbxFerramenta.setFont(new java.awt.Font("Montserrat", 2, 12)); // NOI18N
        cbxFerramenta.setToolTipText("");
        cbxFerramenta.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        cbxFerramenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxFerramentaActionPerformed(evt);
            }
        });
        getContentPane().add(cbxFerramenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 440, 30));

        jButton2.setFont(new java.awt.Font("Montserrat", 2, 12)); // NOI18N
        jButton2.setText("CANCELAR");
        jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.black));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 80, -1));

        jLabel6.setFont(new java.awt.Font("Montserrat", 2, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Data prevista da devolução");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, -1, 14));

        jLabel2.setFont(new java.awt.Font("Montserrat", 2, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Selecione um amigo:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, 25));

        jLabel1.setFont(new java.awt.Font("Montserrat", 2, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Selecione uma ferramenta:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        datadevolucao.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        try {
            datadevolucao.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("####-##-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        datadevolucao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                datadevolucaoActionPerformed(evt);
            }
        });
        getContentPane().add(datadevolucao, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 170, 80, 20));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/degradefundo1.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");
        jLabel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.blue, java.awt.Color.blue, java.awt.Color.blue));
        jLabel5.setPreferredSize(new java.awt.Dimension(538, 600));
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 490, 320));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cbxFerramentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxFerramentaActionPerformed

    }//GEN-LAST:event_cbxFerramentaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        try {
            // recebendo e validando dados da interface gr�fica.
            int ferramentaid ;
            int amigoid ;
            String dataEmprestimo;
            String dataDevolucao;
            String status = "NULL";
           

             ferramentaid = cbxFerramenta.getItemCount();
             amigoid = cbxAmigos.getItemCount();
        
             // Obtendo a data atual
            Date dataAtual = new Date();
            SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
            dataEmprestimo = formatador.format(dataAtual);
            dataDevolucao = this.datadevolucao.getText();


            // envia os dados para o Controlador cadastrar
            if (this.objaluno.CadastrarEmprestimoBD(amigoid,ferramentaid, dataEmprestimo,dataDevolucao,status)) {
                JOptionPane.showMessageDialog(rootPane, "Emprestimo realizado com Sucesso!");
                  this.datadevolucao.setText("");
            }

        } catch (NumberFormatException erro2) {
            JOptionPane.showMessageDialog(null, "Informe um n�mero.");
        } catch (SQLException ex) {
            Logger.getLogger(CadastrarFerramenta.class.getName()).log(Level.SEVERE, null, ex);{
            
        }}
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void datadevolucaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_datadevolucaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_datadevolucaoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RealizarEmprestimo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RealizarEmprestimo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RealizarEmprestimo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RealizarEmprestimo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RealizarEmprestimo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbxAmigos;
    private javax.swing.JComboBox<String> cbxFerramenta;
    private javax.swing.JFormattedTextField datadevolucao;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

    private void setIcon() {
setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon2.png")));
    }

}
