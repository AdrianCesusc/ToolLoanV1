package View;

public class Mensagens1 extends Exception {

    Mensagens1(String msg) {
        super(msg);
    }
}
