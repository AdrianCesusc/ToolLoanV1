package View;

import Model.Amigo;
import java.awt.Toolkit;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GerenciaAmigo extends javax.swing.JFrame {

    private Amigo objAmigo; // Criamos o vinculo com o objAmigo Amigo 

    public GerenciaAmigo() {
        initComponents();
        this.objAmigo = new Amigo(); // carrega objAmigo de Amigo
        this.carregaTabela();
        setIcon();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        b_alterar = new javax.swing.JButton();
        b_apagar = new javax.swing.JButton();
        b_cancelar = new javax.swing.JButton();
        c_telefone = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        c_nome = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableAmigos = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();

        setTitle("Gerenciamento de Amigos");
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        b_alterar.setFont(new java.awt.Font("Montserrat", 2, 10)); // NOI18N
        b_alterar.setText("Alterar");
        b_alterar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        b_alterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_alterarActionPerformed(evt);
            }
        });
        getContentPane().add(b_alterar, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 180, 79, -1));

        b_apagar.setFont(new java.awt.Font("Montserrat", 2, 10)); // NOI18N
        b_apagar.setText("Apagar");
        b_apagar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        b_apagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_apagarActionPerformed(evt);
            }
        });
        getContentPane().add(b_apagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 210, 79, -1));

        b_cancelar.setFont(new java.awt.Font("Montserrat", 2, 10)); // NOI18N
        b_cancelar.setText("Cancelar");
        b_cancelar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        b_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_cancelarActionPerformed(evt);
            }
        });
        getContentPane().add(b_cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 240, 80, -1));

        c_telefone.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        getContentPane().add(c_telefone, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 166, -1));

        jLabel3.setFont(new java.awt.Font("Montserrat", 3, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Telefone");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 72, -1));

        c_nome.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        getContentPane().add(c_nome, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 166, -1));

        jLabel1.setFont(new java.awt.Font("Montserrat", 3, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nome:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 47, -1));

        jTableAmigos.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jTableAmigos.setFont(new java.awt.Font("Montserrat", 2, 12)); // NOI18N
        jTableAmigos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Nome", "Telefone"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableAmigos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableAmigosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableAmigos);
        if (jTableAmigos.getColumnModel().getColumnCount() > 0) {
            jTableAmigos.getColumnModel().getColumn(0).setMinWidth(30);
            jTableAmigos.getColumnModel().getColumn(1).setMinWidth(200);
            jTableAmigos.getColumnModel().getColumn(2).setMinWidth(100);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 354, 151));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/degradefundo1.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");
        jLabel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.blue, java.awt.Color.blue, java.awt.Color.blue));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 280));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void b_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_cancelarActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_b_cancelarActionPerformed

    private void b_alterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_alterarActionPerformed

        try {
            // recebendo e validando os dados dos campos na interface gráfica
            int id = 0;
            String nome = "";
            String telefone = "";
  
            // é validado o tamanho dos valores inseridos nos campos 
            if (this.c_nome.getText().length() < 2) {
                throw new Mensagens1("Por favor insira um nome maior de 2 digitos");
            } else {
                nome = this.c_nome.getText();
            }
            if (this.c_telefone.getText().length() < 2) {
                throw new Mensagens1("Telefone inválido");
            } else {
                telefone  = this.c_telefone.getText();
            }
            
            // Chamamos o método para puxar os dados do Amigo selecionado na ação click dentro da Table
            if (this.jTableAmigos.getSelectedRow() == -1) {
                throw new Mensagens1("Primeiro Selecione um Amigo para Alterar");
            } else {
                id = Integer.parseInt(this.jTableAmigos.getValueAt(this.jTableAmigos.getSelectedRow(), 0).toString());
            }

            // envia os dados para o DAO realizar a alteração
            if (this.objAmigo.AtualizarAmigoBD(nome, id,telefone )) {

            // limpa os dados dos campos da interface
                this.c_nome.setText("");
                this.c_telefone.setText("");
           
            //Avisamos ao usuario que a alteração foi feita com sucesso    
                JOptionPane.showMessageDialog(rootPane, "Amigo Alterado com Sucesso!");

            // Capturamos os possiveis erros    
            }
            System.out.println(this.objAmigo.getListaAmigos().toString());
            } catch (Mensagens1 erro) {
            JOptionPane.showMessageDialog(null, erro.getMessage());
            } catch (NumberFormatException erro2) {
            JOptionPane.showMessageDialog(null, "Verifique os valores inseridos");
            } finally {
            // Atualizamos os dados da tabela 
            carregaTabela(); 
        }
    }//GEN-LAST:event_b_alterarActionPerformed

    private void jTableAmigosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableAmigosMouseClicked

        //Função para carregar os dados do Amigo selecionado na Table
        if (this.jTableAmigos.getSelectedRow() != -1) {
        //Atribuimos para duas variveis o valor dos dados do amigo selecionado pelo usuario      
            String nome = this.jTableAmigos.getValueAt(this.jTableAmigos.getSelectedRow(), 1).toString();
            String telefone = this.jTableAmigos.getValueAt(this.jTableAmigos.getSelectedRow(), 2).toString();
        //Insere os dados das variaveis nos campos da interface gráfica 
            this.c_nome.setText(nome);
            this.c_telefone.setText(telefone);
        }
    }//GEN-LAST:event_jTableAmigosMouseClicked

    private void b_apagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_apagarActionPerformed
        try {
            // recebendo e validando os dados dos campos na interface gráfica
            int id = 0;
            //  Valida que tenha sido selecionado um amigo da Table
            if (this.jTableAmigos.getSelectedRow() == -1) {
                throw new Mensagens1("Primeiro Selecione um Amigo para APAGAR");
            } else {
                id = Integer.parseInt(this.jTableAmigos.getValueAt(this.jTableAmigos.getSelectedRow(), 0).toString());
            }
            // Aviso de confirmação da exclusão do Amigo
            int resposta_usuario = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja APAGAR este Amigo ?");

            if (resposta_usuario == 0) {// clicou em SIM

            // envia os dados para o DAO realizar a exclusão 
            if (this.objAmigo.ExcluirAmigoBD(id)) {

            // limpa os dados dos campos da interface
                    this.c_nome.setText("");
                    this.c_telefone.setText("");
            
            // Informa ao usuario que a ação foi feita com sucesso        
                    JOptionPane.showMessageDialog(rootPane, "Amigo Apagado com Sucesso!");

                }
            }
            // imprimimos os dados do amigo cadastrado no output
                     System.out.println(this.objAmigo.getListaAmigos().toString());
 
            // Capturamos os possiveis erros          
            } catch (Mensagens1 erro) {
            JOptionPane.showMessageDialog(null, erro.getMessage());
            } finally {
            // Atualizamos os dados da tabela 
            carregaTabela();
        }
    }//GEN-LAST:event_b_apagarActionPerformed

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("unchecked")
    
    //Metodo para preencher a tabela com os dados dos Amigos
    public void carregaTabela() {

        DefaultTableModel modelo = (DefaultTableModel) this.jTableAmigos.getModel();
        modelo.setNumRows(0);

        ArrayList<Amigo> minhalista = new ArrayList<>();
        minhalista = objAmigo.getListaAmigos();

        for (Amigo a : minhalista) {
            modelo.addRow(new Object[]{
                a.getId(),
                a.getNome(),
                a.getTelefone(),
               
            });
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GerenciaAmigo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GerenciaAmigo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GerenciaAmigo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GerenciaAmigo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GerenciaAmigo().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b_alterar;
    private javax.swing.JButton b_apagar;
    private javax.swing.JButton b_cancelar;
    private javax.swing.JTextField c_nome;
    private javax.swing.JTextField c_telefone;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableAmigos;
    // End of variables declaration//GEN-END:variables

    private void setIcon() {
setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon2.png")));
    }
}
