
package View;
import Model.Ferramenta;
import java.awt.Toolkit;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class CadastrarFerramenta extends javax.swing.JFrame {
    
    private Ferramenta objFerramenta ;
    
    public CadastrarFerramenta() {
        initComponents();
        this.objFerramenta = new Ferramenta(); 
        setIcon();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        NomeFerramenta = new javax.swing.JTextField();
        tefsd = new javax.swing.JLabel();
        MarcaFerramenta = new javax.swing.JTextField();
        tefsd1 = new javax.swing.JLabel();
        ValorFerramenta = new javax.swing.JTextField();
        tefsd2 = new javax.swing.JLabel();
        CadastrarFerramenta = new javax.swing.JToggleButton();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        jLabel1.setFont(new java.awt.Font("Montserrat", 3, 18)); // NOI18N
        jLabel1.setText("Cadastro de Ferrramentas");

        setTitle("Cadastro de ferramentas");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        NomeFerramenta.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        getContentPane().add(NomeFerramenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 50, 209, 28));

        tefsd.setFont(new java.awt.Font("Montserrat", 3, 14)); // NOI18N
        tefsd.setForeground(new java.awt.Color(255, 255, 255));
        tefsd.setText("Nome:");
        getContentPane().add(tefsd, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, -1, -1));

        MarcaFerramenta.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        getContentPane().add(MarcaFerramenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, 212, 28));

        tefsd1.setFont(new java.awt.Font("Montserrat", 3, 14)); // NOI18N
        tefsd1.setForeground(new java.awt.Color(255, 255, 255));
        tefsd1.setText("Marca:");
        getContentPane().add(tefsd1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, -1, -1));

        ValorFerramenta.setToolTipText("");
        ValorFerramenta.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        getContentPane().add(ValorFerramenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 150, 212, 28));

        tefsd2.setFont(new java.awt.Font("Montserrat", 3, 14)); // NOI18N
        tefsd2.setForeground(new java.awt.Color(255, 255, 255));
        tefsd2.setText("Valor (R$):");
        getContentPane().add(tefsd2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, -1, -1));

        CadastrarFerramenta.setFont(new java.awt.Font("Montserrat", 2, 12)); // NOI18N
        CadastrarFerramenta.setText("CADASTRAR");
        CadastrarFerramenta.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        CadastrarFerramenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CadastrarFerramentaActionPerformed(evt);
            }
        });
        getContentPane().add(CadastrarFerramenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 240, 110, 32));

        jButton1.setFont(new java.awt.Font("Montserrat", 2, 10)); // NOI18N
        jButton1.setText("CANCELAR");
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 250, 70, 20));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/degradefundo1.jpg"))); // NOI18N
        jLabel3.setText("jLabel3");
        jLabel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.blue, java.awt.Color.blue, java.awt.Color.blue));
        jLabel3.setMinimumSize(new java.awt.Dimension(500, 300));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 320));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void CadastrarFerramentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CadastrarFerramentaActionPerformed
        try {
            //recebendo e validando os dados dos campos na interface gráfica
            String nome = "";
            String marca = "";
            double custo ;

            // é validado o tamanho dos valores inseridos nos campos 
            if (this.NomeFerramenta.getText().length() < 2) {
                throw new Mensagens1("Por favor insira um nome maior de 2 digitos");
            } else {
                nome = this.NomeFerramenta.getText();
            }
            if (this.MarcaFerramenta.getText().length() <= 0) {
                throw new Mensagens1("Nome de ferramenta inválido");
            } else {
                marca = this.MarcaFerramenta.getText();
            }
            if (this.ValorFerramenta.getText().length() < 2) {
                throw new Mensagens1("Valor inválido");
            } else {
                custo = Double.parseDouble(this.ValorFerramenta.getText());
            }

            // envia os dados para o DAO realizar o cadastro
            if (this.objFerramenta.CadastrarFerramentaBD(nome, marca, custo)) {
                JOptionPane.showMessageDialog(rootPane, "Ferramenta cadastrada com Sucesso!");

            // limpa os dados dos campos da interface
                this.NomeFerramenta.setText("");
                this.MarcaFerramenta.setText("");
                this.ValorFerramenta.setText("");
            }
            // imprimimos os dados da ferramenta cadastrado no output
            System.out.println(this.objFerramenta.getListaFerramentas().toString());
            
            // Capturamos os possiveis erros 
            } catch (Mensagens1 erro) {
                JOptionPane.showMessageDialog(null, erro.getMessage());
            } catch (NumberFormatException erro2) {
                JOptionPane.showMessageDialog(null, "Verifique os valores inseridos");
            } catch (SQLException ex) {
                Logger.getLogger(CadastrarFerramenta.class.getName()).log(Level.SEVERE, null, ex);
            } 
    }//GEN-LAST:event_CadastrarFerramentaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      this.setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CadastrarFerramenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CadastrarFerramenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CadastrarFerramenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CadastrarFerramenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastrarFerramenta().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton CadastrarFerramenta;
    private javax.swing.JTextField MarcaFerramenta;
    private javax.swing.JTextField NomeFerramenta;
    private javax.swing.JTextField ValorFerramenta;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel tefsd;
    private javax.swing.JLabel tefsd1;
    private javax.swing.JLabel tefsd2;
    // End of variables declaration//GEN-END:variables

    private void setIcon() {
setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon2.png")));
    }
}

