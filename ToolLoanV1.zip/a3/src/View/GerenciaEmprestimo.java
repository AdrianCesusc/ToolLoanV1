package View;

import Model.Emprestimo;
import java.awt.Toolkit;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GerenciaEmprestimo extends javax.swing.JFrame {

    private Emprestimo objEmprestimo; //Criamos o vinculo com o objEmprestimo 

    public GerenciaEmprestimo() {
        initComponents();
        this.objEmprestimo = new Emprestimo(); // carrega objEmprestimo de Emprestimo
        this.carregaTabela();
        setIcon();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableEmprestimos = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setTitle("Gerenciamento de Emprestimos");
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTableEmprestimos.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray, java.awt.Color.darkGray));
        jTableEmprestimos.setFont(new java.awt.Font("Montserrat", 2, 12)); // NOI18N
        jTableEmprestimos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Amigo", "Ferramenta", "Data prevista", "Data do Emprestimo", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableEmprestimos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableEmprestimosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableEmprestimos);
        if (jTableEmprestimos.getColumnModel().getColumnCount() > 0) {
            jTableEmprestimos.getColumnModel().getColumn(0).setMinWidth(10);
            jTableEmprestimos.getColumnModel().getColumn(0).setMaxWidth(50);
            jTableEmprestimos.getColumnModel().getColumn(1).setMinWidth(100);
            jTableEmprestimos.getColumnModel().getColumn(2).setMinWidth(100);
        }

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 810, 170));

        jButton1.setFont(new java.awt.Font("Montserrat", 2, 12)); // NOI18N
        jButton1.setText("SAIR");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 210, 90, 20));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/degradefundo1.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");
        jLabel2.setMaximumSize(new java.awt.Dimension(1000, 370));
        jLabel2.setMinimumSize(new java.awt.Dimension(700, 370));
        jLabel2.setPreferredSize(new java.awt.Dimension(1000, 370));
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 240));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jTableEmprestimosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableEmprestimosMouseClicked
if (this.jTableEmprestimos.getSelectedRow() != -1  ) {
     int selectedRow = this.jTableEmprestimos.getSelectedRow();
     String status = this.jTableEmprestimos.getModel().getValueAt(selectedRow, 5).toString(); // Obtém o valor da coluna "status" (índice 5)
          
    if (status.equals("Pendente")) {
    try {
            // recebendo e validando os dados dos campos na interface gráfica
            int id = 0;
            //  Valida que tenha sido selecionado um emprestimo da Table
            if (this.jTableEmprestimos.getSelectedRow() == -1) {
                throw new Mensagens1("Primeiro Selecione uma ferramenta para Devolver");
            } else {
                id = Integer.parseInt(this.jTableEmprestimos.getValueAt(this.jTableEmprestimos.getSelectedRow(), 0).toString());
            }
            // Aviso de confirmação da devulação do emprestimo
            int resposta_usuario = JOptionPane.showConfirmDialog(null, "Deseja confirmar a devolução da ferramenta?");

            if (resposta_usuario == 0) {// clicou em SIM

            // envia os dados para o DAO realizar a devolucao
            if (this.objEmprestimo.devolvido(id)) {

          
            // Informa ao usuario que a ação foi feita com sucesso        
                    JOptionPane.showMessageDialog(rootPane, "Ferramenta devolvida com sucesso com Sucesso!");

                }
            }}
             // Capturamos os possiveis erros
            catch (Mensagens1 erro) {
            JOptionPane.showMessageDialog(null, erro.getMessage());
            } finally {
            // Atualizamos os dados da tabela 
            carregaTabela();
        }
 
    }
 
        }
    }//GEN-LAST:event_jTableEmprestimosMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
this.setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    @SuppressWarnings("unchecked")
     //Metodo para preencher a tabela com os dados dos Emprestimos
    public void carregaTabela() {

        DefaultTableModel modelo = (DefaultTableModel) this.jTableEmprestimos.getModel();
        modelo.setNumRows(0);
        ArrayList<Emprestimo> minhalista = new ArrayList<>();
        minhalista = objEmprestimo.getListaEmprestimos();
        
        for (Emprestimo a : minhalista) {
            modelo.addRow(new Object[]{
                a.getId(),
                a.getNomeAmigo(),
                a.getNomeFerramenta(),
                a.getDataDevolucao(),
                a.getDataEmprestimo() , 
                a.getStatus()
            });
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GerenciaEmprestimo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GerenciaEmprestimo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GerenciaEmprestimo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GerenciaEmprestimo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GerenciaEmprestimo().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableEmprestimos;
    // End of variables declaration//GEN-END:variables

    private void setIcon() {
setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon2.png")));
    }

}
